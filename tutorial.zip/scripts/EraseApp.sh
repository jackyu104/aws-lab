#!/bin/bash
rm -rf /var/www/html/*
